/**
 * 
 */

alert("This is the date template Boss!");